from machine import Pin
from utime import sleep
import requests
import sys
from datetime import datetime

sleep(0.01) # Wait for USB to connect
led = Pin(5, Pin.OUT)
green = Pin(6, Pin.OUT)
day = datetime.now().strftime('%Y-%m-%d')
times = datetime.now().strftime('%H:%M')
names = input("名前を入力してください：")
print("入力してください（1で出勤2で退勤）:")

for line in sys.stdin:
    if line.strip() == "1":
        try:
            res = requests.post(
                "  https://889a-125-103-211-238.ngrok-free.app/receive",
                json={"message": f"日＝{day},時間＝{times}, 氏名＝{names}, status=出勤"}
            )
            print("送信成功:", res.text)
            green.toggle()
            sleep(0.5)
        except Exception as e:
            led.toggle()
            sleep(0.5)
            print("送信失敗:", e)
    elif line.strip() == "2":
        try:
            res = requests.post(
                "  https://889a-125-103-211-238.ngrok-free.app/receive",
                json={"message": f"日＝{day},時間＝{times}, 氏名＝{names}, status=退勤"}
            )
            print("送信成功:", res.text)
            green.toggle()
            sleep(0.5)
        except Exception as e:
            led.toggle()
            sleep(0.5)
            print("送信失敗:", e)
    else:
        print("1以外が入力されました。再入力してください:")
